from lib.llm.chromadb import get_collection

def get_data_chunks(data, chunk_size=1000, overlap=50):
    """Splits text data into chunks with overlap."""
    chunks = []
    start = 0
    while start < len(data):
        end = min(start + chunk_size, len(data))
        chunks.append(data[start:end])
        start += chunk_size - overlap
    return chunks

def add_chunks_to_chromadb(chunks, collection_name="legal_knowledge_hub"):
    """Adds text chunks into a ChromaDB collection."""

    # Add chunks to the collection
    collection = get_collection(collection_name)
    for i, chunk in enumerate(chunks):
        collection.add(
            documents=[chunk],
            metadatas=[{"chunk_id": i}],
            ids=[f"chunk_{i}"]
        )
    return collection
