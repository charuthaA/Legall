from flask import Flask, request, jsonify
import speech_recognition as sr
import sqlite3

app = Flask(__name__)

# Initialize Speech Recognizer
recognizer = sr.Recognizer()

@app.route('/voice-to-text', methods=['POST'])
def voice_to_text():
    try:
        audio_file = request.files['audio']
        with sr.AudioFile(audio_file) as source:
            audio_data = recognizer.record(source)
            text = recognizer.recognize_google(audio_data)
        return jsonify({"text": text})
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@app.route('/query', methods=['POST'])
def query():
    user_input = request.json.get("input_text")
    # Connect to the database
    conn = sqlite3.connect("legal_data.db")  # Replace with your database
    cursor = conn.cursor()

    # Example: Query logic
    cursor.execute("SELECT response FROM responses WHERE query = ?", (user_input,))
    response = cursor.fetchone()

    conn.close()
    if response:
        return jsonify({"response": response[0]})
    else:
        return jsonify({"response": "No results found."})

if __name__ == '__main__':
    app.run(debug=True)
