from flask_jwt_extended import jwt_required
from flask import Blueprint, jsonify, request
from lib.Mongo.mongo import get_db
from lib.Routes.auth import handle_save_chat, handle_get_chat_history
history = Blueprint("history", __name__)

db = get_db()
chat_history = db["chat_history"]
@history.route('/api/history', methods=['GET'])
@jwt_required()
def get_chat_history():
    try:
        return handle_get_chat_history(chat_history)
        # Fetch chat history based on user_id
    except Exception as e:
        print(f"Error fetching chat history: {e}")  # Debugging log
        return jsonify({'error': str(e)}), 500
    
@jwt_required()
def save_chat():
    try:
        data = request.get_json()
        return handle_save_chat(chat_history,data)
    except Exception as e:
        return jsonify({'error': str(e)}), 500