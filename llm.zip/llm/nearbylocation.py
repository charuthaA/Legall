from flask import Flask, request, jsonify
import requests
import os
from dotenv import load_dotenv

load_dotenv()  # Load environment variables from .env file

app = Flask(__name__)

GOOGLE_MAPS_API_KEY = os.getenv("AIzaSyDapqYILUshzD6-zxdZWzMV5MpbuGwrCAc")  # Use environment variable for API key

@app.route('/nearby_legal_services', methods=['GET'])
def get_nearby_legal_services():
    lat = request.args.get('lat')
    lng = request.args.get('lng')
    radius = request.args.get('radius', default=5000, type=int)  # Default 5km radius
    min_rating = request.args.get('min_rating', default=0, type=float)  # Min rating filter
    
    if not lat or not lng:
        return jsonify({"error": "Missing latitude or longitude"}), 400
    
    # Google Places API URL for nearby search
    places_url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json"
    
    params = {
        "location": f"{lat},{lng}",
        "radius": radius,
        "keyword": "legal consultancy OR law firm OR court OR lawyer OR notary",
        "type": "lawyer|courthouse|notary",
        "key":AIzaSyDapqYILUshzD6-zxdZWzMV5MpbuGwrCAc
    }
    
    response = requests.get(places_url, params=params)
    
    if response.status_code != 200:
        return jsonify({"error": "Failed to fetch data from Google Places API"}), 500
    
    data = response.json()
    
    if "results" not in data:
        return jsonify({"error": "No results found"}), 404

    # Filter results based on min_rating
    filtered_results = [
        {
            "name": place.get("name", "Unknown"),
            "place_id": place.get("place_id"),
            "address": place.get("vicinity", "Address not available"),
            "rating": place.get("rating", 0),
            "location": place["geometry"]["location"]
        }
        for place in data["results"]
        if place.get("rating", 0) >= min_rating
    ]
    
    return jsonify({"results": filtered_results})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000, debug=True)