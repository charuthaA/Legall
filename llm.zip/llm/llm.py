from dotenv import load_dotenv
import os
#from llama_index import LLMPredictor, ServiceContext, SimpleKeywordTableIndex, VectorStoreRetriever
#from langchain.chains import RetrievalQA
import requests
from lib.llm.utils import getDataChunks, createKnowledgeHub

ResponsePrompt = """Consider you are a legal advisor based in India. Your day-to-day job is to reply to legal queries in the most simplified language possible by using the least words. Make sure the reader of the response might not understand legal jargons, so avoid difficult language. You can mention laws, acts, sections, subsections applicable in your response for the sake of reference or to support the accuracy of your response. At the end of the response, also mention the punishments given in the laws for the action if any (optional).

Answer the question using the given knowledge hub as a part of the retriever. Do not answer the question if you think you are unsure about the answer, just reply with "I am not sure about this". Reply in the language of the question. If the question is in Hindi, reply in Hindi; if the question is in Bengali, reply in Bengali; and if the question is in English, reply in English. Use proper laws, acts, sections, and subsections while responding in Hindi.
"""

ActPrompt = """Based on the below text, can you give the related name of law, act, section, subsection associated with it in the context of the Indian judicial system? Get me the response strictly in 2-3 words. Do not format the response in a list or any other format. Just give me the response in plain text. Do not add any sections, subsections, or specific laws. Always give the response in English.
"""

KYRPrompt = """Based on the given data about the user, such as age, gender, city, state, and profession, can you give me the list of 10 specific rights that person must know in his profession? Make the rights gender- and age-specific as well. Make each right a sentence, and do not add any other information such as laws, acts, sections, subsections, or punishments. Do not format the response in a list or any other format. Just give me the rights in plain text, where each right is separated by a new line.

Person: """

SpecsPrompt = """Depending upon the given question, what are the different specifications the given question can be categorized into? The options are ["Criminal Law", "Civil Law", "Common Law", "Statutory Law", "Cyber Law"]. You can return multiple options if the question can be categorized into multiple categories. Return the response in comma-separated values. Do not add anything else in the response.
"""


# Replace OpenAI with Llama3
#llm = LLMPredictor(model_name="Llama3", max_tokens=600)
#service_context = ServiceContext.from_defaults(llm_predictor=llm)


def generateResponse(text, question):
    chunks = getDataChunks(text)
    knowledge_hub = createKnowledgeHub(chunks)
    retriever = knowledge_hub.as_retriever(search_type="similarity", search_kwargs={"k": 2})

    '''chain = RetrievalQA.from_chain_type(
        llm=llm,
        chain_type="stuff",
        retriever=retriever,
        return_source_documents=True,
    )'''

    '''result = chain({"query": ResponsePrompt + "Question: " + question})
    print(result)
    return result['result']'''

def regenerateResponse(text, question, response):
    chunks = getDataChunks(text)
    knowledge_hub = createKnowledgeHub(chunks)
    retriever = knowledge_hub.as_retriever(search_type="similarity", search_kwargs={"k": 2})

    '''chain = RetrievalQA.from_chain_type(
        llm=llm,
        chain_type="stuff",
        retriever=retriever,
        return_source_documents=True,
    )'''

    '''result = chain({"query": ResponsePrompt + "Question: " + question + "\n\nThe user is not satisfied with your previous answer\nPrevious Answer: " + response + "\nPlease provide a better answer."})
    return result['result']'''

def generateChatResponse(text, previousContext, followUpQuestion):
    chunks = getDataChunks(text)
    knowledge_hub = createKnowledgeHub(chunks)
    retriever = knowledge_hub.as_retriever(search_type="similarity", search_kwargs={"k": 2})

    '''chain = RetrievalQA.from_chain_type(
        llm=llm,
        chain_type="stuff",
        retriever=retriever,
        return_source_documents=True,
    )'''

    '''result = chain({"query": ResponsePrompt + "Previous Context: " + previousContext + "\n\nQuestion: " + followUpQuestion})
    return result['result']'''

'''def getAct(question):
    response = llm.predict(prompt=ActPrompt + question)
    return response'''

'''def getSpecs(question):
    response = llm.predict(prompt=SpecsPrompt + question)
    values = response.split(",")
    values = [value.strip() for value in values]
    options = ["Criminal Law", "Civil Law", "Common Law", "Statutory Law", "Cyber Law"]
    values = [value for value in values if value in options]
    return values'''

'''def getKYR(data):
    response = llm.predict(prompt=KYRPrompt + data)
    return response'''

'''def SummarizeLegalText(text, lang):
    prompt = f"Summarize the provided legal text using straightforward language, ensuring retention of all essential legal details. If the document refers to any acts, laws, or sections within the Indian judicial system, explicitly mention them and provide clear explanations in simplified terms. Maintain the approach of preserving crucial legal information while simplifying complex language. Do not introduce any extraneous details or information.\n\n{text}\n\nPlease respond with the appropriate summary strictly in {lang}."
    response = llm.predict(prompt=prompt)
    return response'''
